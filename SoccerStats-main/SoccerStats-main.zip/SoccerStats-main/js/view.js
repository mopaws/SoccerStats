function loadPage(logtest){
  let logBox = document.getElementById("loginBox");
  if(logtest == true){
    logBox.remove();
  }
}
